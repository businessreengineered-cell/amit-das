from fastapi import FastAPI
import os, json

app = FastAPI()

DATA_DIR = "/app/data"
os.makedirs(DATA_DIR, exist_ok=True)
MEMORY_FILE = os.path.join(DATA_DIR, "memory.json")
if not os.path.exists(MEMORY_FILE):
    with open(MEMORY_FILE, "w") as f:
        json.dump({"conversations": []}, f)

def save_memory(entry):
    with open(MEMORY_FILE, "r+") as f:
        data = json.load(f)
        data["conversations"].append(entry)
        f.seek(0)
        json.dump(data, f)

@app.get("/")
async def root():
    return {"status": "Jarvis is alive"}

# Calculator tool
@app.get("/tool/calc")
async def calc(expr: str):
    try:
        result = eval(expr, {"__builtins__": {}})
        return {"result": result}
    except Exception as e:
        return {"error": str(e)}

# Todo tool
todos = []

@app.get("/tool/todo/add")
async def todo_add(item: str):
    todos.append(item)
    return {"todos": todos}

@app.get("/tool/todo/list")
async def todo_list():
    return {"todos": todos}

# Device control tool
devices = {"light": False, "fan": False}

@app.get("/tool/device/{name}/{action}")
async def device_control(name: str, action: str):
    if name in devices:
        devices[name] = (action == "on")
        return {"devices": devices}
    return {"error": "Unknown device"}
